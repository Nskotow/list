<?php include "includes/header.php"; ?>


<?php

if(empty($_GET['accept'])){
header("Location:index.php"); 
}else

if(!isset($_GET['accept'])){
header("Location:index.php"); 
}else


if(isset($_GET['accept'])){


$query = query("UPDATE list SET accept='да' WHERE id=". escape_string($_GET['accept']));

confirm($query);

header("Location:index.php");

}

?>