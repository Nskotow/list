<?php include "includes/header.php"; ?>

  <!-- Main Sidebar Container -->
<?php include "includes/side_bar.php"; ?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<div class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
							<h1 class="m-0 text-dark">Edit products</h1>
						</div><!-- /.col -->
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"><a href="#">Home</a></li>
								<li class="breadcrumb-item active">Dashboard</li>
							</ol>
						</div><!-- /.col -->
					</div><!-- /.row -->
				</div><!-- /.container-fluid -->
			</div>
			<!-- /.content-header -->

			<!-- Main content -->
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-lg-12">
						
			
						
						
				
<?php 

$username = "";
$email    =	"";
$text	  = "";			
							
if(isset($_GET['edit'])){
$query = query("SELECT * FROM list WHERE id =" . escape_string($_GET['edit']) . " ");
confirm($query);

while($row = fetch_array($query)){

$username =	escape_string($row['username']);
$email    =	escape_string($row['email']);
$text     =	escape_string($row['text']);

}


}

update_list();
?>
						
						
							<!-- /.card -->
							<div class="center">
						

								<form action="" method="POST" enctype="multipart/form-data">
									<div class="form-group ">
										<label for="exampleFormControlInput1">Имя</label>
										<input type="text" name="username" class="form-control" id="exampleFormControlInput1" value="<?php echo $username; ?>" required>
									</div>
									<div class="form-group ">
										<label for="exampleFormControlInput1">E-mail пользователя</label>
										<input type="text" class="form-control" name="email" id="exampleFormControlInput1" value="<?php echo $email; ?>" required>
									</div>
									<div class="form-group ">
										<label for="exampleFormControlInput1">Пользовательский текс</label>
										  <textarea class="form-control" name="text" id="exampleFormControlTextarea1" rows="3" required><?php echo $text ?></textarea>
									</div>
                                    
							
									
						

									<div class="form-group">
										<button type="submit" name="update" class="btn btn-primary btn-lg btn-block">Потвердить</button>
									</div>

										
								</form>

							</div>
							<!-- /.card -->
						</div>
						<!-- /.col-md-6 -->
						<div class="col-lg-6">

							<!-- /.card -->


						</div>
						<!-- /.col-md-6 -->
					</div>
					<!-- /.row -->
				</div>
				<!-- /.container-fluid -->
			</div>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->

		<!-- Control Sidebar -->
		<aside class="control-sidebar control-sidebar-dark">
			<!-- Control sidebar content goes here -->
		</aside>
		<!-- /.control-sidebar -->

		<!-- Main Footer -->
		<footer class="main-footer">
			<strong>&copy; 2020 </strong>
		</footer>
	</div>
	<!-- ./wrapper -->

	<!-- REQUIRED SCRIPTS -->

	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- AdminLTE -->
	<script src="dist/js/adminlte.js"></script>

	<!-- OPTIONAL SCRIPTS -->
	<script src="plugins/chart.js/Chart.min.js"></script>
	<script src="dist/js/demo.js"></script>
	<script src="dist/js/pages/dashboard3.js"></script>
</body>

</html>
