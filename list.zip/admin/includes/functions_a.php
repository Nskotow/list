<?php



//CONECT TO 
function query($sql){

global $con;

return mysqli_query($con,$sql);
}



//HELPER MESSAGE


//IF QEURY FAILED
function confirm($result){
global $con;

if(!$result) {

die("QUERY FAILED " . mysqli_error($con));
}
}

//ESCAPING HACKS
function escape_string($string){

global $con;

return mysqli_real_escape_string($con, $string);
}


function fetch_array($result){

return mysqli_fetch_array($result);

}


//DISPLAY on start page 

function get_list_in_Admin(){

$query	= query("SELECT * FROM list ORDER BY id DESC");

confirm($query);



while($row = fetch_array($query)){




$product_image = 	
$product = <<<LIST


<tr>
<td>
{$row['username']}
</td>
<td> <div class="text-success mr-1">{$row['email']}</div></td>
<td>
<span class="text-success mr-1">
{$row['text']}
</span>
</td>
<td>
<span class="text-success mr-1">
{$row['accept']}
</span>
</td>
<td>
<span class="text-success mr-1">
<a href="accept.php?accept={$row['id']}">утвердить</a>
</span>
</td>
<td>
<span class="text-success mr-1">
<a href="edit.php?edit={$row['id']}">редактировать</a>
</span>
</td>
</tr>
LIST;
echo $product;



}	





}






function update_list(){
if(isset($_POST['update'])){


$username       =escape_string($_POST['username']);
$email          =escape_string($_POST['email']);
$text           =escape_string($_POST['text']);



$query = query("UPDATE list SET username='$username', email='$email', text='$text', edit='да' WHERE id=". escape_string($_GET['edit']));


confirm($query);
echo "Обновил";


}else{

}



}





?>


