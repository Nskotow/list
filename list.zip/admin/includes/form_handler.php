<?php  


function userLoggin(){
global $con;
	
	$error_array = array();
if(isset($_POST['enter'])) {

	$username = mysqli_real_escape_string($con, $_POST['name']); 

	$_SESSION['name'] = $username; //Store username into session variable 
	$password = mysqli_real_escape_string($con, $_POST['password']); //Get password

	$check_database_query = mysqli_query($con, "SELECT * FROM admin WHERE admin_name='$username' AND admin_password='$password'");
	$check_login_query = mysqli_num_rows($check_database_query);

	if($check_login_query == 1) {
		$row = mysqli_fetch_array($check_database_query);
		$username = $row['admin_name'];
		
		$_SESSION['admin_name'] = $username;
		header("Location: index.php");
		exit();
	}
	else {
		echo "<span class='text-danger'>Пользователь не найден</span>";
		}
	

	}

	
}
?>